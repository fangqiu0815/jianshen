//
//  JYCollection.m
//  JianShen
//
//  Created by 陈小娟 on 16/11/4.
//  Copyright © 2016年 xinbo. All rights reserved.
//

#import "JYCollection.h"

@implementation JYCollection

@end
