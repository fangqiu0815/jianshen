//
//  JYCollectionViewCell.m
//  JianShen
//
//  Created by 陈小娟 on 16/11/4.
//  Copyright © 2016年 xinbo. All rights reserved.
//

#import "JYCollectionViewCell.h"

@implementation JYCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
   
}



@end
