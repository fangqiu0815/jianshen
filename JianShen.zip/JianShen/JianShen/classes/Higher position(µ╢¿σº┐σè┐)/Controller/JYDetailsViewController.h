
#import <UIKit/UIKit.h>
@class JYPosition;
@interface JYDetailsViewController : UIViewController
//标题
@property(nonatomic,strong)NSString * topTitle;
/** 地址*/
@property(nonatomic,strong)NSString * url;
@end
