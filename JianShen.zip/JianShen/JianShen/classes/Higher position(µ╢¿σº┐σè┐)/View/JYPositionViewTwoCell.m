//
//  JYPositionViewTwoCell.m
//  JianShen
//
//  Created by 陈小娟 on 16/10/31.
//  Copyright © 2016年 xinbo. All rights reserved.
//

#import "JYPositionViewTwoCell.h"
#import "JYPosition.h"
#import "UIImageView+WebCache.h"
@interface JYPositionViewTwoCell()
@property (weak, nonatomic) IBOutlet UIImageView *iconImageView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *subTitleLabel;


@end
@implementation JYPositionViewTwoCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
}

+ (instancetype)tableViewCellWithTableView:(UITableView *)tableView{
    JYPositionViewTwoCell *cell = [tableView dequeueReusableCellWithIdentifier:@"two"];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle]loadNibNamed:@"JYPositionViewTwoCell" owner:nil options:nil] lastObject];
    }
    return cell;
}

-(void)setPosition:(JYPosition *)position{
    self.titleLabel.text= position.title;
    self.subTitleLabel.text=[NSString stringWithFormat:@"%ld人觉得有用",position.likecount];
    [self.iconImageView sd_setImageWithURL:[NSURL URLWithString:position.imglink]];
    self.iconImageView.contentMode = UIViewContentModeScaleAspectFill;
    self.iconImageView.clipsToBounds = YES;

}

@end
