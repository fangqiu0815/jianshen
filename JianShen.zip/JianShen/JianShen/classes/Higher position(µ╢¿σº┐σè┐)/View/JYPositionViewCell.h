//
//  JYPositionViewCell.h
//  JianShen
//
//  Created by 陈小娟 on 16/10/28.
//  Copyright © 2016年 xinbo. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JYPosition;
@interface JYPositionViewCell : UITableViewCell
@property(nonatomic,strong)JYPosition * position;

+ (instancetype)tableViewCellWithTableView:(UITableView *)tableView;

@end
