//
//  JYPosition.m
//  JianShen
//
//  Created by 陈小娟 on 16/10/28.
//  Copyright © 2016年 xinbo. All rights reserved.
//

#import "JYPosition.h"

@implementation JYPosition

@end
