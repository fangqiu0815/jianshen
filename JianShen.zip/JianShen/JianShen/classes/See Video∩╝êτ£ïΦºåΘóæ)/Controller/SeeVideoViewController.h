//
//  SeeVideoViewController.h
//  JianShen
//
//  Created by 陈小娟 on 16/10/27.
//  Copyright © 2016年 xinbo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SeeVideoViewController : UIViewController

@end
