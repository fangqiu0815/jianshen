//
//  JYSkillCell.h
//  JianShen
//
//  Created by 陈小娟 on 16/11/1.
//  Copyright © 2016年 xinbo. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JYSkill;
@interface JYSkillCell : UITableViewCell
@property(nonatomic,strong)JYSkill * skill;
@end
