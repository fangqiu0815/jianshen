//
//  JYSkill.m
//  JianShen
//
//  Created by 陈小娟 on 16/11/1.
//  Copyright © 2016年 xinbo. All rights reserved.
//

#import "JYSkill.h"

@implementation JYSkill

@end
