//
//  JYSkill.h
//  JianShen
//
//  Created by 陈小娟 on 16/11/1.
//  Copyright © 2016年 xinbo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JYSkill : NSObject
@property(nonatomic,strong)NSString * imglink;
@property(nonatomic,strong)NSString * likecount;
@property(nonatomic,strong)NSString * title;
@property(nonatomic,strong)NSString * url;
@end
