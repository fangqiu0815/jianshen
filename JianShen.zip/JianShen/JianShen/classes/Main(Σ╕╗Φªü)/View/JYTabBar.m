

#import "JYTabBar.h"
@interface  JYTabBar ()
/**保存上一次点击的按钮*/
@property(nonatomic,strong)UIButton * preBtn;
@end
@implementation JYTabBar

//-(void)layoutSubviews{
//    [super layoutSubviews];
//    CGFloat btnW=JYScreenW/(self.items.count+1);
//    CGFloat btnH=self.jy_height;
//    int i=0;
//    for (UIButton * btn in self.subviews) {
//        if ([btn isKindOfClass:NSClassFromString(@"UITabBarButton")]) {
//            []
//        }
//    }
//    

    
//    
//}

@end
