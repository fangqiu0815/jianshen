

#import <UIKit/UIKit.h>

@interface UIImage (Stretch)
// 设置图片的拉伸区域(以中心区域拉伸)
-(instancetype)stretchCenter;
@end
