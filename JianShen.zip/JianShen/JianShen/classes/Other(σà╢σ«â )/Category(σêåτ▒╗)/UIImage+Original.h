

#import <UIKit/UIKit.h>

@interface UIImage (Original)
+(UIImage *)imageWithOriginal:(NSString *)imageName;
@end
