
#import <UIKit/UIKit.h>

@interface UIImage (CircleImage)
//获取一个圆角的图片
-(instancetype)circleImage;
@end
