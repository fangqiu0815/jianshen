
#import <UIKit/UIKit.h>

@interface UIBarButtonItem (Item)

+(UIBarButtonItem *)creatItemWithImage:(UIImage*)image heighImage:(UIImage *)heighImage addTaget:(id)taget action:(SEL)action;
@end
