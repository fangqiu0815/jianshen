//
//  JYHealthyDetailsViewController.h
//  JianShen
//
//  Created by 陈小娟 on 16/11/2.
//  Copyright © 2016年 xinbo. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JYHealthy;
@interface JYHealthyDetailsViewController : UIViewController
/** 帖子数据模型 */
@property (nonatomic,strong) JYHealthy *healthy;
//标题
@property(nonatomic,strong)NSString * topTitle;
/** 地址*/
@property(nonatomic,strong)NSString * url;

@end
