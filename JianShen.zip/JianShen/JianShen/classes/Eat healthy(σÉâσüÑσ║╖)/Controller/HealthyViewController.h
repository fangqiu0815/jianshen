

#import <UIKit/UIKit.h>

@interface HealthyViewController : UITableViewController

@end
